//
//  textFieldDelegate.swift
//  Meme
//
//  Created by khaled alshehri on 20/09/1441 AH.
//  Copyright © 1441 test. All rights reserved.
//

import Foundation
import UIKit

class TextFieldDelegate : NSObject, UITextFieldDelegate {
    
    // Action when user click on textField
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.text = ""
    }
    
    //  When a user presses return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.endEditing(true)
        return true;
    }
    
}
