//
//  Meme.swift
//  Meme
//
//  Created by khaled alshehri on 23/09/1441 AH.
//  Copyright © 1441 test. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
    
}
