//
//  ViewController.swift
//  Meme
//
//  Created by khaled alshehri on 19/09/1441 AH.
//  Copyright © 1441 test. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    // MARK: Text Field Delegate objects
    let textFieldDelegate = TextFieldDelegate()
    
    var top: String = "TOP"
    var bottom: String = "BOTTOM"
    
    @IBOutlet weak var imagePickerView: UIImageView!

    @IBOutlet weak var cameraButton: UIBarButtonItem!
    
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var bottomTextField: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var toolBar: UIToolbar!
    
    var memedImage: UIImage?
    var savedMeme: Meme?
    
    let memeTextAttributes: [NSAttributedString.Key: Any] = [
        // This will provide the white fill.
        NSAttributedString.Key.foregroundColor: UIColor.white,
        // This will give us our black outline.
        NSAttributedString.Key.strokeColor: UIColor.black,
        // Here we select the font name.
        NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key.strokeWidth: 2.0,
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTextField(topTextField, top)
        setupTextField(bottomTextField, bottom)
    }

    func setupTextField(_ textField: UITextField, _ defaultText: String) {
        textField.delegate = textFieldDelegate
        textField.textAlignment = .center
        textField.defaultTextAttributes = memeTextAttributes
        textField.textAlignment = .center
        textField.text = defaultText
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        // check if the device able to use camera or not
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        
        subscribeToKeyboardNotifications()
    }
    
    override func viewWillDisappear(_ animated: Bool) {

        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            imagePickerView.image = image
        }
        dismiss(animated: true, completion: nil)
    }
    
    private func imagePickerControllerDidCancel(picker: UIImagePickerController!) {
        dismiss(animated: true, completion: nil)
    }
    
    func pickFromSource(_ source: UIImagePickerController.SourceType) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self;
        imagePicker.sourceType = source
        present(imagePicker, animated: true, completion: nil)
    }

    @IBAction func pickAnImageFromAlbum(_ sender: Any) {
        pickFromSource(.photoLibrary)
    }

    @IBAction func pickAnImageFromCamera(_ sender: Any) {
        pickFromSource(.camera)
    }
    
    
    @objc func keyboardWillShow(_ notification:Notification) {

        view.frame.origin.y = 0 - getKeyboardHeight(notification)
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
        
        view.frame.origin.y = 0
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        
        // Only move the view when editing the bottom text
        if bottomTextField.isFirstResponder {
            return keyboardSize.cgRectValue.height
        } else {
            return 0
        }
        
    }
    
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unsubscribeFromKeyboardNotifications() {
        
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    
    
    func save() {
        
        // Save the meme
        if let topText = topTextField.text,
            let bottomText = bottomTextField.text,
            let originalImage = imagePickerView.image,
            let memedImage = memedImage{
            
            let meme = Meme(topText: topText, bottomText: bottomText, originalImage: originalImage, memedImage: memedImage)
            
            // Add it to the memes array in the Application Delegate
            let object = UIApplication.shared.delegate
            let appDelegate = object as! AppDelegate
            appDelegate.memes.append(meme)
        }
        
        
    }
    
    func generateMemedImage() -> UIImage {
        
        // Hide tool bar and navigation bar
        memeEditorControlBars(areHidden: true)
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        // Show tool bar and navigation bar
        memeEditorControlBars(areHidden: false)
        
        return memedImage
    }
    
    func memeEditorControlBars(areHidden isHidden: Bool) {
        toolBar.isHidden = isHidden
        navigationBar.isHidden = isHidden
    }
    
    @IBAction func cancel(_ sender: Any) {
        
        topTextField.text = top
        topTextField.endEditing(true)
        bottomTextField.text = bottom
        bottomTextField.endEditing(true)
        imagePickerView.image = nil
        
        dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func shareMeme() {
        
        memedImage = generateMemedImage()
        if let image = memedImage {
            
            let controller = UIActivityViewController(activityItems: [image], applicationActivities: nil)
            
            controller.completionWithItemsHandler = {
                (activity, success, items, error) in
                if(success && error == nil){
                    // Save copy of meme and close activity view
                    self.save()
                    
                    self.dismiss(animated: true, completion: nil)
                    
                } else {
                    
                    let controller = UIAlertController()
                    controller.title = "Meme Share Incomplete"
                    controller.message = "Share was failed or cancelled."
                    
                    let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) { action in controller.dismiss(animated: true, completion: nil)
                    }
                    
                    controller.addAction(okAction)
                    self.present(controller, animated: true, completion: nil)
                    
                }
            }
            
            present(controller, animated: true, completion: nil)

        }
        
    }
    
}
